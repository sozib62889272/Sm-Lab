import { motion } from 'framer-motion'
import { ArrowRight, Shield, Zap, Globe } from 'lucide-react'
import { ConnectKitButton } from 'connectkit'
import { TokenUSDC } from '@web3icons/react'

const BADGES = [
  { icon: Zap, label: 'Sub-second finality' },
  { icon: Shield, label: 'USDC native gas' },
  { icon: Globe, label: 'Arc Network' },
]

export default function HeroSection() {
  return (
    <section className="relative min-h-dvh flex flex-col items-center justify-center text-center px-4 overflow-hidden">
      {/* Background orbs */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[700px] h-[700px] rounded-full bg-[#4a90d9]/8 blur-[120px]" />
        <div className="absolute bottom-1/4 left-1/4 w-[400px] h-[400px] rounded-full bg-[#acc6e9]/6 blur-[100px]" />
        {/* grid lines */}
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage:
              'linear-gradient(var(--border-strong) 1px, transparent 1px), linear-gradient(90deg, var(--border-strong) 1px, transparent 1px)',
            backgroundSize: '80px 80px',
          }}
        />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 32 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className="relative z-10 max-w-4xl mx-auto space-y-8"
      >
        {/* Badge row */}
        <div className="flex flex-wrap items-center justify-center gap-2">
          {BADGES.map(({ icon: Icon, label }) => (
            <span
              key={label}
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full glass text-xs font-semibold text-[var(--accent)] tracking-wide uppercase"
              style={{ letterSpacing: '0.07em' }}
            >
              <Icon size={11} strokeWidth={2.5} />
              {label}
            </span>
          ))}
        </div>

        {/* Headline */}
        <div className="space-y-4">
          <h1 className="display text-5xl sm:text-7xl font-700 text-[var(--ink)] text-balance leading-[1.05]">
            The Future of{' '}
            <span className="grad-text">Onchain Finance</span>
          </h1>
          <p className="text-lg sm:text-xl text-[var(--muted)] max-w-2xl mx-auto leading-relaxed text-pretty">
            SM Labs delivers cutting-edge DeFi tooling on Arc — swap, pay, and get
            test USDC in seconds with zero ETH overhead.
          </p>
        </div>

        {/* CTA row */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
          <ConnectKitButton />
          <a
            href="#features"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold text-[var(--ink-2)] glass border border-white/10 hover:bg-white/10 hover:text-[var(--ink)] transition-all group"
          >
            Explore features
            <ArrowRight size={15} className="group-hover:translate-x-0.5 transition-transform" />
          </a>
        </div>

        {/* Stats bar */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="flex flex-wrap items-center justify-center gap-px mt-4"
        >
          {[
            { value: '< 1s', label: 'Finality' },
            { value: 'USDC', label: 'Native Gas' },
            { value: '~$0.00', label: 'Tx Fee' },
            { value: 'Arc', label: 'Network' },
          ].map(({ value, label }, i) => (
            <div
              key={label}
              className={`px-6 py-3 ${i !== 3 ? 'border-r border-white/10' : ''}`}
            >
              <div className="display font-700 text-2xl text-[var(--accent)] tabular-nums">{value}</div>
              <div className="text-xs text-[var(--subtle)] mt-0.5">{label}</div>
            </div>
          ))}
        </motion.div>

        {/* USDC icon hint */}
        <div className="flex items-center justify-center gap-2 text-xs text-[var(--subtle)]">
          <TokenUSDC variant="branded" size={16} />
          <span>Powered by USDC on Arc Network</span>
        </div>
      </motion.div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 0.6 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1"
      >
        <div className="w-px h-8 bg-gradient-to-b from-transparent to-[var(--accent)]/50 animate-pulse" />
        <div className="w-1 h-1 rounded-full bg-[var(--accent)]/50" />
      </motion.div>
    </section>
  )
}
