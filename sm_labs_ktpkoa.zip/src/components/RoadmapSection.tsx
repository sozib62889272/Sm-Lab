import { motion } from 'framer-motion'
import { CheckCircle2, Circle, Clock } from 'lucide-react'

type Status = 'done' | 'active' | 'upcoming'

interface Milestone {
  quarter: string
  title: string
  items: string[]
  status: Status
}

const MILESTONES: Milestone[] = [
  {
    quarter: 'Q1 2026',
    title: 'Foundation',
    status: 'done',
    items: [
      'SM Labs concept & whitepaper',
      'Team formation',
      'Arc Network integration research',
      'Smart contract architecture design',
    ],
  },
  {
    quarter: 'Q2 2026',
    title: 'Core Build',
    status: 'done',
    items: [
      'USDC Faucet on Arc Testnet',
      'Wallet connection & chain support',
      'Landing page v1 launch',
      'Community Discord & socials',
    ],
  },
  {
    quarter: 'Q3 2026',
    title: 'DeFi Toolkit',
    status: 'active',
    items: [
      'Token swap interface',
      'USDC payment module',
      'Transaction history dashboard',
      'Mobile-first UX polish',
    ],
  },
  {
    quarter: 'Q4 2026',
    title: 'Ecosystem Growth',
    status: 'upcoming',
    items: [
      'DEX liquidity aggregator',
      'Cross-chain USDC bridge (CCTP)',
      'Developer SDK & docs',
      'Mainnet Arc deployment',
    ],
  },
  {
    quarter: 'Q1 2027',
    title: 'Protocol Launch',
    status: 'upcoming',
    items: [
      'SM Labs governance token',
      'Yield & savings vaults',
      'Partner integrations',
      'DAO formation',
    ],
  },
]

const STATUS_CONFIG: Record<Status, { color: string; bg: string; border: string; Icon: typeof CheckCircle2 }> = {
  done: {
    color: '#7dcfa0',
    bg: 'rgba(125,207,160,0.12)',
    border: 'rgba(125,207,160,0.25)',
    Icon: CheckCircle2,
  },
  active: {
    color: '#4a90d9',
    bg: 'rgba(74,144,217,0.12)',
    border: 'rgba(74,144,217,0.25)',
    Icon: Clock,
  },
  upcoming: {
    color: '#5c7898',
    bg: 'rgba(92,120,152,0.08)',
    border: 'rgba(92,120,152,0.15)',
    Icon: Circle,
  },
}

export default function RoadmapSection() {
  return (
    <section id="roadmap" className="py-24 px-4">
      <div className="max-w-4xl mx-auto space-y-16">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center space-y-3"
        >
          <span className="inline-block px-3 py-1 rounded-full glass text-xs font-semibold text-[var(--gold)] uppercase tracking-widest">
            Roadmap
          </span>
          <h2 className="display text-4xl sm:text-5xl font-700 text-[var(--ink)]">
            Building the future,{' '}
            <span className="grad-text">step by step</span>
          </h2>
          <p className="text-[var(--muted)] max-w-xl mx-auto text-pretty">
            Our journey from concept to fully deployed DeFi protocol on Arc Network.
          </p>
        </motion.div>

        {/* Timeline */}
        <div className="relative">
          {/* Vertical line */}
          <div className="absolute left-6 top-0 bottom-0 w-px bg-gradient-to-b from-[#4a90d9]/30 via-[#acc6e9]/20 to-transparent hidden md:block" />

          <div className="space-y-6">
            {MILESTONES.map((milestone, i) => {
              const { color, bg, border, Icon } = STATUS_CONFIG[milestone.status]
              return (
                <motion.div
                  key={milestone.quarter}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, margin: '-60px' }}
                  transition={{ duration: 0.55, delay: i * 0.07, ease: [0.22, 1, 0.36, 1] }}
                  className="md:pl-20 relative"
                >
                  {/* Dot */}
                  <div
                    className="hidden md:flex absolute left-3 top-5 w-6 h-6 rounded-full items-center justify-center border"
                    style={{ background: bg, borderColor: border }}
                  >
                    <div className="w-2 h-2 rounded-full" style={{ background: color }} />
                  </div>

                  {/* Card */}
                  <div
                    className="rounded-2xl p-6 space-y-4 glass transition-all duration-300 hover:scale-[1.01]"
                    style={{
                      borderColor: milestone.status === 'active' ? 'rgba(74,144,217,0.35)' : undefined,
                      borderWidth: milestone.status === 'active' ? 1 : undefined,
                      borderStyle: milestone.status === 'active' ? 'solid' : undefined,
                    }}
                  >
                    {/* Header row */}
                    <div className="flex items-start justify-between gap-3">
                      <div className="space-y-0.5">
                        <div className="text-xs font-semibold tabular-nums" style={{ color }}>
                          {milestone.quarter}
                        </div>
                        <h3 className="display font-700 text-[var(--ink)] text-lg">{milestone.title}</h3>
                      </div>
                      <div
                        className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold"
                        style={{ background: bg, color, border: `1px solid ${border}` }}
                      >
                        <Icon size={11} />
                        {milestone.status === 'done' ? 'Complete' : milestone.status === 'active' ? 'In Progress' : 'Upcoming'}
                      </div>
                    </div>

                    {/* Items */}
                    <ul className="space-y-2">
                      {milestone.items.map((item) => (
                        <li key={item} className="flex items-center gap-2.5 text-sm text-[var(--muted)]">
                          <div
                            className="w-1.5 h-1.5 rounded-full shrink-0"
                            style={{ background: color, opacity: milestone.status === 'upcoming' ? 0.4 : 1 }}
                          />
                          <span className={milestone.status === 'upcoming' ? 'opacity-60' : ''}>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </motion.div>
              )
            })}
          </div>
        </div>
      </div>
    </section>
  )
}
