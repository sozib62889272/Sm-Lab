import { motion } from 'framer-motion'
import { Droplets, ArrowLeftRight, Send, ShieldCheck, Zap, Globe } from 'lucide-react'

const FEATURES = [
  {
    icon: Droplets,
    title: 'Arc USDC Faucet',
    desc: 'Claim free testnet USDC instantly. No waiting, no forms — just connect your wallet and receive funds in one click.',
    accent: '#4a90d9',
    href: '#faucet',
  },
  {
    icon: ArrowLeftRight,
    title: 'Swap Tokens',
    desc: 'Swap between tokens on Arc with lightning speed. Powered by Arc native USDC liquidity and sub-second finality.',
    accent: '#6baed6',
    href: '#swap',
  },
  {
    icon: Send,
    title: 'USDC Payments',
    desc: 'Send USDC to any address on Arc. Predictable fees, instant settlement, no ETH required for gas.',
    accent: '#acc6e9',
    href: '#payment',
  },
  {
    icon: ShieldCheck,
    title: 'USDC-Native Gas',
    desc: 'Pay for every transaction in USDC — no wrapped tokens, no separate gas wallets, just one asset for everything.',
    accent: '#7dcfa0',
  },
  {
    icon: Zap,
    title: 'Sub-second Finality',
    desc: 'Transactions confirm in under a second. Build apps that feel instant because they actually are.',
    accent: '#f5c542',
  },
  {
    icon: Globe,
    title: 'Arc Network',
    desc: 'Built on Arc — Circle\'s EVM chain where USDC is the native gas token. Stable fees, predictable costs, always.',
    accent: '#e86d7a',
  },
]

const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.08 } },
}

const item = {
  hidden: { opacity: 0, y: 24 },
  show: { opacity: 1, y: 0, transition: { duration: 0.55, ease: [0.22, 1, 0.36, 1] } },
}

export default function FeaturesSection() {
  return (
    <section id="features" className="py-24 px-4">
      <div className="max-w-6xl mx-auto space-y-16">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center space-y-3"
        >
          <span className="inline-block px-3 py-1 rounded-full glass text-xs font-semibold text-[var(--accent)] uppercase tracking-widest">
            Platform
          </span>
          <h2 className="display text-4xl sm:text-5xl font-700 text-[var(--ink)] text-balance">
            Everything you need{' '}
            <span className="grad-text">onchain</span>
          </h2>
          <p className="text-[var(--muted)] max-w-xl mx-auto text-pretty">
            A complete DeFi toolkit for Arc Network — faucet, swap, and payments
            bundled in a single, clean interface.
          </p>
        </motion.div>

        {/* Grid */}
        <motion.div
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: '-80px' }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"
        >
          {FEATURES.map(({ icon: Icon, title, desc, accent, href }) => (
            <motion.div key={title} variants={item}>
              <a
                href={href ?? '#'}
                className={`block h-full rounded-2xl glass-strong p-6 space-y-4 transition-all duration-300 hover:scale-[1.02] hover:border-white/20 ${href ? 'cursor-pointer' : 'cursor-default'}`}
              >
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center"
                  style={{ background: `${accent}18`, border: `1px solid ${accent}30` }}
                >
                  <Icon size={20} style={{ color: accent }} strokeWidth={2} />
                </div>
                <div className="space-y-1.5">
                  <h3 className="display font-600 text-[var(--ink)] text-base">{title}</h3>
                  <p className="text-sm text-[var(--muted)] leading-relaxed text-pretty">{desc}</p>
                </div>
              </a>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
