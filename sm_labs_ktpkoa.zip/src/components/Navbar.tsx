import { useState, useEffect } from 'react'
import { ConnectKitButton } from 'connectkit'
import { Zap, Menu, X } from 'lucide-react'

const NAV_LINKS = [
  { label: 'Features', href: '#features' },
  { label: 'Faucet', href: '#faucet' },
  { label: 'Swap', href: '#swap' },
  { label: 'Pay', href: '#payment' },
  { label: 'Roadmap', href: '#roadmap' },
]

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 48)
    window.addEventListener('scroll', handler, { passive: true })
    return () => window.removeEventListener('scroll', handler)
  }, [])

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'glass border-b border-white/10 shadow-lg' : 'bg-transparent'
      }`}
    >
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        {/* Logo */}
        <a href="#" className="flex items-center gap-2.5 group">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#4a90d9] to-[#acc6e9] flex items-center justify-center shadow-md group-hover:scale-105 transition-transform">
            <Zap size={16} className="text-[#0a1628]" strokeWidth={2.5} />
          </div>
          <span className="display font-700 text-[var(--ink)] text-lg tracking-tight">
            SM <span className="text-[var(--accent)]">Labs</span>
          </span>
        </a>

        {/* Desktop nav */}
        <ul className="hidden md:flex items-center gap-1">
          {NAV_LINKS.map(({ label, href }) => (
            <li key={href}>
              <a
                href={href}
                className="px-3 py-1.5 rounded-md text-sm font-medium text-[var(--muted)] hover:text-[var(--ink)] hover:bg-white/5 transition-all"
              >
                {label}
              </a>
            </li>
          ))}
        </ul>

        {/* Connect wallet */}
        <div className="hidden md:block">
          <ConnectKitButton />
        </div>

        {/* Mobile hamburger */}
        <button
          className="md:hidden p-2 rounded-lg text-[var(--muted)] hover:text-[var(--ink)] hover:bg-white/5 transition-all"
          onClick={() => setMenuOpen((o) => !o)}
          aria-label="Toggle menu"
        >
          {menuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </nav>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="md:hidden glass border-t border-white/10 px-4 py-4 space-y-1">
          {NAV_LINKS.map(({ label, href }) => (
            <a
              key={href}
              href={href}
              onClick={() => setMenuOpen(false)}
              className="block px-3 py-2.5 rounded-lg text-sm font-medium text-[var(--ink-2)] hover:text-[var(--ink)] hover:bg-white/5 transition-all"
            >
              {label}
            </a>
          ))}
          <div className="pt-2">
            <ConnectKitButton />
          </div>
        </div>
      )}
    </header>
  )
}
