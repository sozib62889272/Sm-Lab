import { Zap, Twitter, Github, MessageCircle } from 'lucide-react'

export default function FooterSection() {
  return (
    <footer className="border-t border-white/8 py-12 px-4 mt-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Brand */}
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#4a90d9] to-[#acc6e9] flex items-center justify-center">
              <Zap size={15} className="text-[#0a1628]" strokeWidth={2.5} />
            </div>
            <div>
              <div className="display font-700 text-[var(--ink)] text-sm leading-tight">SM Labs</div>
              <div className="text-xs text-[var(--subtle)]">Built on Arc Network</div>
            </div>
          </div>

          {/* Links */}
          <nav className="flex items-center gap-6">
            {['Features', 'Faucet', 'Swap', 'Pay', 'Roadmap'].map((item) => (
              <a
                key={item}
                href={`#${item.toLowerCase()}`}
                className="text-xs text-[var(--subtle)] hover:text-[var(--ink-2)] transition-colors"
              >
                {item}
              </a>
            ))}
          </nav>

          {/* Socials */}
          <div className="flex items-center gap-2">
            {[
              { Icon: Twitter, label: 'Twitter', href: '#' },
              { Icon: Github, label: 'GitHub', href: '#' },
              { Icon: MessageCircle, label: 'Discord', href: '#' },
            ].map(({ Icon, label, href }) => (
              <a
                key={label}
                href={href}
                aria-label={label}
                className="w-8 h-8 rounded-lg glass flex items-center justify-center text-[var(--subtle)] hover:text-[var(--accent)] hover:bg-white/10 transition-all"
              >
                <Icon size={14} />
              </a>
            ))}
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-8 pt-6 border-t border-white/6 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-[var(--subtle)]">
          <span>2026 Sm Labs. All rights reserved.</span>
          <div className="flex items-center gap-1.5">
            <span>Powered by</span>
            <span className="font-semibold text-[var(--accent)]">ARC</span>
            <span>·</span>
            <span>Built by</span>
            <span className="font-semibold text-[var(--ink-2)]">Sojib</span>
          </div>
        </div>
      </div>
    </footer>
  )
}
