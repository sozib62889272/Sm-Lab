import { useState } from 'react'
import { motion } from 'framer-motion'
import { Send, CheckCircle2, Loader2, AlertCircle, ExternalLink } from 'lucide-react'
import { useAccount, useWriteContract, useWaitForTransactionReceipt, useSwitchChain } from 'wagmi'
import { erc20Abi, isAddress } from 'viem'
import { arcTestnet } from 'viem/chains'
import { ConnectKitButton } from 'connectkit'
import { TokenUSDC } from '@web3icons/react'
import { getUsdc, buildTxExplorerUrl } from '@/onchain-facts'
import { parseAmount, Amount, usdcDecimalsFor } from '@/onchain-money'
import { useReadContract } from 'wagmi'

const CHAIN_ID = arcTestnet.id
const USDC = getUsdc(CHAIN_ID)!

function parseOnchainError(error: unknown): string {
  const msg = (error as Error)?.message?.toLowerCase() ?? ''
  if (msg.includes('user rejected') || (error as { code?: number })?.code === 4001)
    return 'Transaction cancelled.'
  if (msg.includes('insufficient funds') || msg.includes('exceeds balance'))
    return 'Insufficient USDC balance.'
  if (msg.includes('reverted')) return 'Transaction reverted. Please try again.'
  return 'Something went wrong. Please try again.'
}

export default function PaymentSection() {
  const { address, chainId, isConnected } = useAccount()
  const { switchChain } = useSwitchChain()
  const [recipient, setRecipient] = useState('')
  const [amount, setAmount] = useState('')

  const isWrongChain = isConnected && chainId !== CHAIN_ID
  const recipientValid = isAddress(recipient)
  const amountNum = parseFloat(amount)
  const amountValid = !isNaN(amountNum) && amountNum > 0

  // Balance
  const { data: rawBalance, refetch } = useReadContract({
    address: USDC.address as `0x${string}`,
    abi: erc20Abi,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    chainId: CHAIN_ID,
    query: { enabled: !!address },
  })
  const balance = rawBalance != null
    ? Amount.fromRaw(rawBalance, usdcDecimalsFor(CHAIN_ID)).toFixed(2)
    : '—'

  const {
    writeContract,
    data: txHash,
    isPending,
    error: writeError,
    reset,
  } = useWriteContract()

  const { isLoading: isConfirming, isSuccess } = useWaitForTransactionReceipt({
    hash: txHash,
    chainId: CHAIN_ID,
  })

  const handleSend = () => {
    if (!isConnected || !recipientValid || !amountValid) return
    if (isWrongChain) {
      switchChain({ chainId: CHAIN_ID })
      return
    }
    const parsed = parseAmount(CHAIN_ID, amount)
    writeContract({
      address: USDC.address as `0x${string}`,
      abi: erc20Abi,
      functionName: 'transfer',
      args: [recipient, parsed.raw],
      chainId: CHAIN_ID,
    })
  }

  const explorerUrl = txHash ? buildTxExplorerUrl(CHAIN_ID, txHash) : undefined

  const handleReset = () => {
    reset()
    setAmount('')
    setRecipient('')
    void refetch()
  }

  return (
    <section id="payment" className="py-24 px-4">
      <div className="max-w-xl mx-auto space-y-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center space-y-3"
        >
          <span className="inline-block px-3 py-1 rounded-full glass text-xs font-semibold text-[var(--accent)] uppercase tracking-widest">
            Payments
          </span>
          <h2 className="display text-4xl font-700 text-[var(--ink)]">
            Send USDC
          </h2>
          <p className="text-[var(--muted)] max-w-md mx-auto text-pretty">
            Transfer USDC to any wallet on Arc. Instant settlement, stable fees, no ETH required.
          </p>
        </motion.div>

        {/* Card */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.55, delay: 0.1 }}
          className="glass-strong rounded-3xl p-6 space-y-5 glow-accent"
        >
          {/* Success state */}
          {isSuccess && (
            <div className="flex flex-col items-center gap-4 py-6">
              <div className="w-14 h-14 rounded-full bg-[var(--success)]/15 border border-[var(--success)]/30 flex items-center justify-center">
                <CheckCircle2 size={28} className="text-[var(--success)]" />
              </div>
              <div className="text-center space-y-1">
                <p className="font-700 text-[var(--ink)] display">Transfer confirmed!</p>
                <p className="text-sm text-[var(--muted)]">{amount} USDC sent successfully.</p>
              </div>
              {explorerUrl && (
                <a
                  href={explorerUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 text-xs text-[var(--accent)] hover:underline"
                >
                  View on explorer <ExternalLink size={12} />
                </a>
              )}
              <button
                onClick={handleReset}
                className="px-6 py-2.5 rounded-xl glass border border-white/15 text-sm font-semibold text-[var(--ink-2)] hover:bg-white/10 transition-all"
              >
                Send another
              </button>
            </div>
          )}

          {!isSuccess && (
            <>
              {/* Balance */}
              {isConnected && (
                <div className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/8 text-sm">
                  <div className="flex items-center gap-2 text-[var(--muted)]">
                    <TokenUSDC variant="branded" size={16} />
                    Balance
                  </div>
                  <span className="font-600 text-[var(--ink)] tabular-nums">{balance} USDC</span>
                </div>
              )}

              {/* Recipient */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-[var(--ink-2)]">Recipient Address</label>
                <input
                  value={recipient}
                  onChange={(e) => setRecipient(e.target.value)}
                  placeholder="0x..."
                  className={`w-full px-4 py-3 rounded-xl bg-white/5 border text-sm text-[var(--ink)] placeholder:text-[var(--subtle)] outline-none mono transition-colors ${
                    recipient && !recipientValid
                      ? 'border-[var(--danger)]/50 focus:border-[var(--danger)]'
                      : 'border-white/10 focus:border-[var(--accent)]/40'
                  }`}
                />
                {recipient && !recipientValid && (
                  <p className="text-xs text-[var(--danger)] flex items-center gap-1">
                    <AlertCircle size={11} /> Invalid address
                  </p>
                )}
              </div>

              {/* Amount */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-[var(--ink-2)]">Amount</label>
                  {isConnected && rawBalance != null && (
                    <button
                      onClick={() =>
                        setAmount(Amount.fromRaw(rawBalance, usdcDecimalsFor(CHAIN_ID)).toFixed(6))
                      }
                      className="text-xs text-[var(--accent)] hover:text-[var(--accent-hover)] transition-colors"
                    >
                      Max
                    </button>
                  )}
                </div>
                <div className="relative">
                  <input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="0.00"
                    className="w-full px-4 py-3 pr-20 rounded-xl bg-white/5 border border-white/10 focus:border-[var(--accent)]/40 text-sm text-[var(--ink)] placeholder:text-[var(--subtle)] outline-none tabular-nums transition-colors"
                  />
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1.5 text-sm font-semibold text-[var(--muted)] pointer-events-none">
                    <TokenUSDC variant="branded" size={14} />
                    USDC
                  </div>
                </div>
              </div>

              {/* Error */}
              {writeError && (
                <div className="flex items-start gap-2 p-3 rounded-xl bg-[var(--danger)]/10 border border-[var(--danger)]/20 text-xs text-[var(--danger)]">
                  <AlertCircle size={13} className="mt-0.5 shrink-0" />
                  {parseOnchainError(writeError)}
                </div>
              )}

              {/* CTA */}
              {!isConnected ? (
                <div className="flex justify-center">
                  <ConnectKitButton label="Connect to send" />
                </div>
              ) : isWrongChain ? (
                <button
                  onClick={() => switchChain({ chainId: CHAIN_ID })}
                  className="w-full py-3.5 rounded-xl font-semibold text-sm bg-[var(--danger)] text-white hover:opacity-90 transition-opacity"
                >
                  Switch to Arc Testnet
                </button>
              ) : (
                <button
                  onClick={handleSend}
                  disabled={!recipientValid || !amountValid || isPending || isConfirming}
                  className="w-full py-3.5 rounded-xl font-semibold text-sm bg-[var(--accent)] text-[#0a1628] hover:bg-[var(--accent-hover)] active:scale-[0.98] transition-all disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {isPending ? (
                    <><Loader2 size={15} className="animate-spin" /> Confirm in wallet...</>
                  ) : isConfirming ? (
                    <><Loader2 size={15} className="animate-spin" /> Confirming...</>
                  ) : (
                    <><Send size={15} /> Send USDC</>
                  )}
                </button>
              )}
            </>
          )}
        </motion.div>
      </div>
    </section>
  )
}
