import { useState } from 'react'
import { motion } from 'framer-motion'
import { Droplets } from 'lucide-react'
import { useAccount, useSwitchChain, useReadContract } from 'wagmi'
import { erc20Abi } from 'viem'
import { arcTestnet } from 'viem/chains'
import { ConnectKitButton } from 'connectkit'
import { TokenUSDC } from '@web3icons/react'
import { getUsdc } from '@/onchain-facts'
import { usdcDecimalsFor, Amount } from '@/onchain-money'
import { toast } from 'sonner'

const CHAIN_ID = arcTestnet.id
const USDC = getUsdc(CHAIN_ID)!

// Faucet amounts in USDC
const AMOUNTS = ['10', '25', '50', '100']

export default function FaucetSection() {
  const { address, chainId, isConnected } = useAccount()
  const { switchChain } = useSwitchChain()
  const [selected, setSelected] = useState('10')

  // Read USDC balance
  const { data: rawBalance } = useReadContract({
    address: USDC.address as `0x${string}`,
    abi: erc20Abi,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    chainId: CHAIN_ID,
    query: { enabled: !!address },
  })

  const balance = rawBalance != null
    ? Amount.fromRaw(rawBalance, usdcDecimalsFor(CHAIN_ID)).toFixed(2)
    : '—'

  const isWrongChain = isConnected && chainId !== CHAIN_ID



  const handleClaim = () => {
    if (!isConnected) return
    if (isWrongChain) {
      switchChain({ chainId: CHAIN_ID })
      return
    }
    toast.info('Use the "Get test USDC" button in the Arc Studio sidebar to receive testnet USDC.')
  }

  return (
    <section id="faucet" className="py-24 px-4">
      <div className="max-w-2xl mx-auto space-y-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center space-y-3"
        >
          <span className="inline-block px-3 py-1 rounded-full glass text-xs font-semibold text-[#4a90d9] uppercase tracking-widest">
            Faucet
          </span>
          <h2 className="display text-4xl font-700 text-[var(--ink)]">
            Get Test USDC
          </h2>
          <p className="text-[var(--muted)] max-w-md mx-auto text-pretty">
            Receive free Arc testnet USDC to explore all SM Labs features without spending real funds.
          </p>
        </motion.div>

        {/* Card */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.55, delay: 0.1 }}
          className="glass-strong rounded-3xl p-8 space-y-7 glow-accent"
        >
          {/* Balance row */}
          {isConnected && (
            <div className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/8">
              <div className="flex items-center gap-2 text-sm text-[var(--muted)]">
                <TokenUSDC variant="branded" size={18} />
                Your balance
              </div>
              <span className="display font-600 text-[var(--ink)] tabular-nums">{balance} USDC</span>
            </div>
          )}

          {/* Amount selector */}
          <div className="space-y-3">
            <p className="text-sm font-semibold text-[var(--ink-2)]">Select amount</p>
            <div className="grid grid-cols-4 gap-2">
              {AMOUNTS.map((amt) => (
                <button
                  key={amt}
                  onClick={() => setSelected(amt)}
                  className={`py-2.5 rounded-xl text-sm font-semibold transition-all ${
                    selected === amt
                      ? 'bg-[#4a90d9] text-white shadow-md'
                      : 'glass text-[var(--muted)] hover:text-[var(--ink)] hover:bg-white/10'
                  }`}
                >
                  {amt}
                </button>
              ))}
            </div>
          </div>

          {/* Info note */}
          <div className="flex items-start gap-3 p-4 rounded-xl bg-[#4a90d9]/10 border border-[#4a90d9]/20">
            <Droplets size={16} className="text-[#4a90d9] mt-0.5 shrink-0" />
            <p className="text-xs text-[var(--muted)] leading-relaxed">
              Use the <span className="font-semibold text-[var(--accent)]">"Get test USDC"</span> button
              in the Arc Studio sidebar to receive testnet USDC directly to your connected wallet.
            </p>
          </div>

          {/* CTA */}
          {!isConnected ? (
            <div className="flex justify-center">
              <ConnectKitButton label="Connect to claim" />
            </div>
          ) : isWrongChain ? (
            <button
              onClick={() => switchChain({ chainId: CHAIN_ID })}
              className="w-full py-3.5 rounded-xl font-semibold text-sm bg-[var(--danger)] text-white hover:opacity-90 transition-opacity"
            >
              Switch to Arc Testnet
            </button>
          ) : (
            <button
              onClick={handleClaim}
              className="w-full py-3.5 rounded-xl font-semibold text-sm bg-[#4a90d9] text-white hover:bg-[#5a9fd9] active:scale-[0.98] transition-all"
            >
              <span className="flex items-center justify-center gap-2">
                <Droplets size={16} />
                Claim {selected} USDC
              </span>
            </button>
          )}
        </motion.div>
      </div>
    </section>
  )
}
