import { useState } from 'react'
import { motion } from 'framer-motion'
import { ArrowUpDown, ChevronDown, Info } from 'lucide-react'
import { useAccount, useSwitchChain } from 'wagmi'
import { arcTestnet } from 'viem/chains'
import { ConnectKitButton } from 'connectkit'
import { toast } from 'sonner'

const CHAIN_ID = arcTestnet.id

const TOKENS = [
  { symbol: 'USDC', name: 'USD Coin', color: '#2775ca' },
  { symbol: 'ETH', name: 'Ethereum', color: '#627eea' },
  { symbol: 'WBTC', name: 'Wrapped Bitcoin', color: '#f7931a' },
]

export default function SwapSection() {
  const { isConnected, chainId } = useAccount()
  const { switchChain } = useSwitchChain()
  const [fromToken, setFromToken] = useState(TOKENS[1])
  const [toToken, setToToken] = useState(TOKENS[0])
  const [fromAmount, setFromAmount] = useState('')
  const isWrongChain = isConnected && chainId !== CHAIN_ID

  const handleFlip = () => {
    setFromToken(toToken)
    setToToken(fromToken)
    setFromAmount('')
  }

  const handleSwap = () => {
    if (!isConnected) return
    if (isWrongChain) {
      switchChain({ chainId: CHAIN_ID })
      return
    }
    toast.info('Swap routing is coming soon. Connect a DEX or Uniswap integration on Arc to activate.')
  }

  // Estimated output — placeholder until a real price feed is wired
  const toAmount = fromAmount && !isNaN(Number(fromAmount)) && Number(fromAmount) > 0
    ? '—'
    : ''

  return (
    <section id="swap" className="py-24 px-4">
      <div className="max-w-xl mx-auto space-y-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center space-y-3"
        >
          <span className="inline-block px-3 py-1 rounded-full glass text-xs font-semibold text-[#6baed6] uppercase tracking-widest">
            Swap
          </span>
          <h2 className="display text-4xl font-700 text-[var(--ink)]">
            Swap Tokens
          </h2>
          <p className="text-[var(--muted)] max-w-md mx-auto text-pretty">
            Exchange tokens instantly on Arc with USDC-native gas and sub-second confirmations.
          </p>
        </motion.div>

        {/* Swap card */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.55, delay: 0.1 }}
          className="glass-strong rounded-3xl p-6 space-y-3 glow-accent"
        >
          {/* From */}
          <div className="rounded-2xl bg-white/5 border border-white/8 p-4 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs text-[var(--subtle)] font-medium">From</span>
            </div>
            <div className="flex items-center gap-3">
              <input
                type="number"
                value={fromAmount}
                onChange={(e) => setFromAmount(e.target.value)}
                placeholder="0.00"
                className="flex-1 bg-transparent text-2xl font-600 text-[var(--ink)] display tabular-nums outline-none placeholder:text-[var(--subtle)] min-w-0"
              />
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/8 border border-white/10 cursor-default">
                <div
                  className="w-5 h-5 rounded-full"
                  style={{ background: fromToken.color, opacity: 0.9 }}
                />
                <span className="text-sm font-semibold text-[var(--ink)]">{fromToken.symbol}</span>
                <ChevronDown size={13} className="text-[var(--subtle)]" />
              </div>
            </div>
          </div>

          {/* Flip */}
          <div className="flex justify-center">
            <button
              onClick={handleFlip}
              className="w-9 h-9 rounded-xl glass border border-white/15 flex items-center justify-center text-[var(--muted)] hover:text-[var(--accent)] hover:bg-white/10 transition-all active:scale-90"
            >
              <ArrowUpDown size={16} />
            </button>
          </div>

          {/* To */}
          <div className="rounded-2xl bg-white/5 border border-white/8 p-4 space-y-2">
            <span className="text-xs text-[var(--subtle)] font-medium">To</span>
            <div className="flex items-center gap-3">
              <div className="flex-1 text-2xl font-600 text-[var(--subtle)] display tabular-nums">
                {toAmount || '0.00'}
              </div>
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/8 border border-white/10 cursor-default">
                <div
                  className="w-5 h-5 rounded-full"
                  style={{ background: toToken.color, opacity: 0.9 }}
                />
                <span className="text-sm font-semibold text-[var(--ink)]">{toToken.symbol}</span>
                <ChevronDown size={13} className="text-[var(--subtle)]" />
              </div>
            </div>
          </div>

          {/* Info row */}
          <div className="flex items-center gap-1.5 px-1 pt-1 text-xs text-[var(--subtle)]">
            <Info size={12} />
            <span>Price feeds and routing coming soon via Arc DEX integration.</span>
          </div>

          {/* CTA */}
          {!isConnected ? (
            <div className="flex justify-center pt-2">
              <ConnectKitButton label="Connect to swap" />
            </div>
          ) : isWrongChain ? (
            <button
              onClick={() => switchChain({ chainId: CHAIN_ID })}
              className="w-full py-3.5 rounded-xl font-semibold text-sm bg-[var(--danger)] text-white hover:opacity-90 transition-opacity"
            >
              Switch to Arc Testnet
            </button>
          ) : (
            <button
              onClick={handleSwap}
              disabled={!fromAmount || Number(fromAmount) <= 0}
              className="w-full py-3.5 rounded-xl font-semibold text-sm bg-[#6baed6] text-[#0a1628] hover:bg-[#7abde5] active:scale-[0.98] transition-all disabled:opacity-40 disabled:cursor-not-allowed"
            >
              Swap {fromToken.symbol} → {toToken.symbol}
            </button>
          )}
        </motion.div>
      </div>
    </section>
  )
}
