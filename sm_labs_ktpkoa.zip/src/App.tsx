import Navbar from './components/Navbar'
import HeroSection from './components/HeroSection'
import FeaturesSection from './components/FeaturesSection'
import FaucetSection from './components/FaucetSection'
import SwapSection from './components/SwapSection'
import PaymentSection from './components/PaymentSection'
import RoadmapSection from './components/RoadmapSection'
import FooterSection from './components/FooterSection'

export default function App() {
  return (
    <div className="min-h-dvh relative">
      {/* Ambient background overlay */}
      <div className="fixed inset-0 pointer-events-none" style={{ background: 'var(--bg-gradient)', zIndex: -1 }} />

      <Navbar />

      <main>
        <HeroSection />

        {/* Divider */}
        <div className="max-w-6xl mx-auto px-4">
          <div className="h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
        </div>

        <FeaturesSection />

        <div className="max-w-6xl mx-auto px-4">
          <div className="h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
        </div>

        <FaucetSection />

        <div className="max-w-6xl mx-auto px-4">
          <div className="h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
        </div>

        <SwapSection />

        <div className="max-w-6xl mx-auto px-4">
          <div className="h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
        </div>

        <PaymentSection />

        <div className="max-w-6xl mx-auto px-4">
          <div className="h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
        </div>

        <RoadmapSection />
      </main>

      <FooterSection />
    </div>
  )
}
